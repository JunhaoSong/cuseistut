function GS=geometrical_spreading(dist,depth)
%% --------------------------------------------------------------------------
% Geometrical spreading term in 1D velocity model
%  GS=geometrical_spreading(dist,depth)
%
%  dist=Great Circle Arc Distance between source and station (in degree)
%  depth=source depth (in km)
%  GS=geometrical spreading term (1/km^2)
%  
%  **Based on energy decay as
%    GS^2=E/Es=1/(4pi*r^2)
%    GS can be used to estimate the ray length RL=1/sqrt(4*pi)/GS
%% --------------------------------------------------------------------------

Radius=6371; % radius of the earth

%% To read the IASP91 model (velocity and ray parameters)
ray_p_dep0=load('/DATA2/spectral_analysis/2015-04-25-mww78-nepal-2/depth_phase/TT_M/rayparam_iasp_P_H'); %source depth (km)
ray_p_temp=load('/DATA2/spectral_analysis/2015-04-25-mww78-nepal-2/depth_phase/TT_M/rayparam_iasp_P'); % ray parameter (s/km)
% IASP91 model (depth(km), radius(km), Vp(km/s), Vs(km/s))
ISAP91=load('/DATA2/spectral_analysis/2015-04-25-mww78-nepal-2/depth_phase/TT_M/isap91.txt'); 


%% Source region velocity and ray parameter from interpolation of IASP91 model
isap_dep0=ISAP91(:,1); % depth column (km)
isap_Vp0=ISAP91(:,3); % Vp column (km/s)

%% To get the Vp, Vs (slowness) in the source and station region
Vp_source=interp1(isap_dep0,isap_Vp0,depth,'Linear'); % Vp in source (km/s)
Sp_source=1/Vp_source; % P wave slowness in source (s/km)

Vp_station=interp1(isap_dep0,isap_Vp0,0,'Linear'); 
Sp_station=1/Vp_station; % Vp Vs in station region (surface, km/s)

%% Radius of source and station (km)
R_source=(Radius-depth);
R_station=Radius;


%% To get Ray parameters
RP_dist0=ray_p_temp(:,1); % in degree
RP=ray_p_temp(:,2:end); % ray parameter in s/km

[dep0,dist0]=meshgrid(ray_p_dep0,RP_dist0);

Ndep0=length(ray_p_dep0);
Ndist0=length(RP_dist0);
N0=Ndep0*Ndist0;

DIST=20:0.01:96; % Distance for the ray parameter interpolation (in degree)
EV_DEP=ones(size(DIST))*depth; % source depth for ray parameter interpolation (km)

RP_EV=interp2(dep0,dist0,RP,EV_DEP,DIST,'linear'); % Direct P Ray parameter(source_depth,distance) in s/km

ray_p=interp1(DIST,RP_EV,dist,'Linear'); % the ray parameter of direct P wave (s/km)


%% (1) the geometrical spreading term (related to the source-receiver distance)
% Calculate the dp(dist)/d(dist) term
dRP_EV=diff(RP_EV); % s/km
d_DIST=diff(DIST); % in degree
dRP_dDist=dRP_EV./d_DIST; % dP(dist)/d(dist) in s/(km*degree)
DIST_diff=DIST(2:end)-d_DIST(1)/2;

dPR_EV_station=interp1(DIST_diff,dRP_dDist,dist,'Linear'); % ray parameter difference for this evernt-station pair

% To get the incident angles from slowness and ray parameter
theta1=asind(ray_p/Sp_source);
theta2=asind(ray_p/Sp_station);

% Geometrical spreading term (1/km)

GS=sqrt(abs(ray_p.*dPR_EV_station*180/pi*(Radius)^2./((Sp_station.*R_source.*R_station)^2*sind(dist).*cosd(theta1).*cosd(theta2)))); % GS~1/sqrt(4pi*Ray_length^2)
end
