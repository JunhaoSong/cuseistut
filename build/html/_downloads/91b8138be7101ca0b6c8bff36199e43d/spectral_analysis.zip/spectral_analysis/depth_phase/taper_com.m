function [a]=taper_suli(a0,width)

%% cos^2 taper
%% t is the time series
%% edicted by Suli 2017-03-30

n=length(a0);
a=a0;

for i = 1 : n
	if i/n <width
		a(i)=a0(i)*power(sin(0.5*pi*i/(n*width)),2);
	end
	if i/n > 1-width
		a(i)=a0(i)*power(sin(0.5*pi*(n-i)/(n*width)),2);
	end
end

