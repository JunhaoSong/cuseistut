function tstar = tstarWS2000(freq,gcarc,lat,long)

% Function to evauluate the attenuation of P waves with the parameter t*.
% Please cite:
%Warren, L.M. and P.M. Shearer, Investigating the frequency dependence of mantle Q by stacking P and PP spectra, %J. Geophys. Res., 105, 25,391-25,402, 2000



   GCARC = (30:5:90);
   TT = [ 6.1710  5.8011;
 6.8995  6.5228;
 7.6048  7.2202;
 8.2827  7.8898;
 8.9313  8.5303;
 9.5497  9.1412;
 10.1379  9.7224;
 10.6959 10.2737;
11.2235 10.7952;
 11.7206 11.2866;
 12.1867 11.7472;
 12.6210 12.1762;
 13.0222 12.5732];T1 = interp1(GCARC,TT(:,1),gcarc,'linear');
T2 = interp1(GCARC,TT(:,2),gcarc,'linear');


   t_um = 2.*60.*(T1-T2);   % get times from TT/tt91.P_qtest220
   t_lm = 60.*9.5497 - t_um;
   tau1 = 10000.;
   tau2_um = 1./(2.*pi*2.5);
   tau2_lm = 1./(2.*pi*0.8);
   qm_um = 170;
   qm_lm = 595;

   om = 2.*pi*freq;
   q_um = 1./((1./qm_um)*(2./pi)*atan(om*(tau1 - tau2_um)./(1. + om.^2*tau1*tau2_um)));
   q_lm = 1./((1./qm_lm)*(2./pi)*atan(om*(tau1 - tau2_lm)./(1. + om.^2*tau1*tau2_lm)));
   tstar = t_um./q_um + t_lm./q_lm ;%+ DT;
   return
