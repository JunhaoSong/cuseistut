function RP=radiation_pattern(M,takeoff,Azi,wavetype)
%% --------------------------------------------------------------------------
% Calculate radiation pattern based on the takeoff angle and moment tensor
% Only contain the e1*M*e2' term
% DON'T include the 1/(4*pi*rho*Vp_source^3*Ray_len) term
%
%
% RP=radiation_pattern(M,takeoff,Azi,wavetpye)
%
% M is the moment tensor in the Matlab coordinate (x-north;y-west;z-up)
% if moment tensor is in other coordinate system, need to be transform
% first: e.g.   GCMT x-t-south;y-p-east;z-r-up
%               Aki book: x-north;y-east;z-down
%
% takeoff is from the negative z axis (in degree)
%
% Azi is the azimuth of the station compared with the source
%
% depth is the depth of the source (in km)
%
% wavetype='P' for P wave and 'S' for S wave
%% --------------------------------------------------------------------------

s_a=sind(-Azi);
c_a=cosd(-Azi); % azimuth

%% P
if strcmp(wavetype,'P')
    
    s_t=sind(180-takeoff);
    c_t=cosd(180-takeoff); % takeoff angle for P wave
    
    
    e_r=[s_t*c_a s_t*s_a c_t]; % P take-off vector
    
    
    RP=e_r*M*e_r';
    
%% SV    
elseif strcmp(wavetype,'S')
    s_t2=sind(180-takeoff);
    c_t2=cosd(180-takeoff);
    
    e_r2=[s_t2*c_a s_t2*s_a c_t2]; % S take-off vector
    e_v2=[sind(takeoff-90)*c_a sind(takeoff-90)*s_a -cosd(takeoff-90)];
    % S wave polarity (perpendicular to the ray)
    
    Polarity_S=sign(e_r2(1:2)*e_v2(1:2)'); % Polarity of the outgoing S wave (compared with the P wave)
    
    RP=Polarity_S*e_v2*M*e_r2';
    
else
    error('wavetype should be set to be P or S');
end

end
