%% this is a function to correct attenuation for far-field spectrum


function tp = corre(f)
for i=1:length(f)
if f(i) <= 0.1
    tp(i)=exp(-3.1415926*f(i)*(0.9 - 0.1*log10(f(i))));
else if f(i) <= 1
    tp(i)=exp(-3.1415926*f(i)*(0.5 - 0.5*log10(f(i))));
else
    tp(i)=exp(-3.1415926*f(i)*(0.5 - 0.1*log10(f(i))));
end
end
end

