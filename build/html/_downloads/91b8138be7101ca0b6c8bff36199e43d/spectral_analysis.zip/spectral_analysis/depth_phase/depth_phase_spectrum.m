function [depth_time,response_depth,anp_dep,ph_dep,ffn_dep]=depth_phase_spectrum(filename,window_length,datalength,M,path)

%% read in the sac files info
[t,a,p]=readsac_com(filename);
Azi=p(26);
dist=p(25)/111.195;  %%degree
depth=p(24);  %%km
%depth=19;
delta=p(1);

response_p=ones(1,datalength)*0; % synthetic time series including p
response_depth=ones(1,datalength)*0; % synthetic time series including p and depth phases

depth_time=0:delta:((datalength-1)*delta);% synthetic time 

[RP,raylength,anp_p]=direct_P(dist,depth,Azi,M,path);
[t_sp,anp_sp]=depth_phase_sP(dist,depth,Azi,M,path);
[t_pp,anp_pp]=depth_phase_pP(dist,depth,Azi,M,path);

%p(7)=60;

% the relative arrival times of different depth phases
%P_point=find(abs((t-p(7)))==min(abs(t-p(7))));   %%  p(7):T0
%sP_point=find(abs((t-p(7)-t_sp))==min(abs(t-p(7)-t_sp)));
%pP_point=find(abs((t-p(7)-t_pp))==min(abs(t-p(7)-t_pp)));
P_point=round((datalength-window_length/delta)/2);
sP_point=round(t_sp/delta+P_point);
pP_point=round(t_pp/delta+P_point);

% the relative amplitude of different phases

response_p(P_point)=anp_p/anp_p;

response_depth(P_point)= anp_p/anp_p;
if sP_point <(datalength-P_point)
response_depth(sP_point)=anp_sp/anp_p;
end
if pP_point<(datalength-P_point)
response_depth(pP_point)=anp_pp/anp_p;
end

% response_p=dirac(depth_time-depth_time(P_point));
% 
% if sP_point <(datalength-P_point)
%      response_depth=response_p+anp_sp/anp_p*dirac(depth_time-depth_time(sP_point));
% end
% 
% 
% if pP_point<(datalength-P_point)
%      response_depth=response_depth+anp_pp/anp_p*dirac(depth_time-depth_time(sP_point));
% end

% calculate the spectra for the depth phases
[anp_dep1,ph_dep1,ffn_dep1]=sacfft(response_p,depth_time);
[anp_dep2,ph_dep2,ffn_dep2]=sacfft(response_depth,depth_time);

anp_dep=anp_dep2/max(anp_dep2);
%anp_dep=anp_dep2./anp_dep1;
ffn_dep=ffn_dep1;
ph_dep=anp_dep;

